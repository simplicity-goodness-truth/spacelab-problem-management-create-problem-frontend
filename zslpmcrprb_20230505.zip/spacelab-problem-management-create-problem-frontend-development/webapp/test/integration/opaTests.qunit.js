/* global QUnit */

sap.ui.require([
	"zslpmcrprb/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});